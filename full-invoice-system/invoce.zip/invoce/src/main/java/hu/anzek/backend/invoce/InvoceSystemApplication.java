package hu.anzek.backend.invoce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoceSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvoceSystemApplication.class, args);
	}

}
